<?php

include_once WILMER_CORE_SHORTCODES_PATH . '/gallery-blocks/functions.php';
include_once WILMER_CORE_SHORTCODES_PATH . '/gallery-blocks/gallery-blocks.php';