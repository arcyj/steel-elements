<?php

include_once WILMER_CORE_SHORTCODES_PATH . '/animated-switch-slider/functions.php';
include_once WILMER_CORE_SHORTCODES_PATH . '/animated-switch-slider/animated-switch-slider.php';