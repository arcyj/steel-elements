<?php

get_header();

wilmer_mikado_get_title();

do_action('wilmer_mikado_action_before_main_content');

wilmer_core_get_single_portfolio();

get_footer();